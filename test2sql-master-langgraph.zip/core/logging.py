def log(msg: str):
    return {"logs": [msg]}